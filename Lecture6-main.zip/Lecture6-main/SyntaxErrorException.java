public class SyntaxErrorException extends Exception {
        /**
         * Construct a SyntaxErrorException with the specified message
         */
        SyntaxErrorException(String message) {
                super(message);
        }
}

